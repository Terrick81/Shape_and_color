
using UnityEngine;

public class HandlerGamePage : MonoBehaviour
{
    private void OnEnable()
    {
        Education.UpdateLayer();
    }
}
