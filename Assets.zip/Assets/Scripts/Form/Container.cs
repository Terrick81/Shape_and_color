using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Container : MonoBehaviour
{
    /// <summary>
    ///     rectangle, star, triangle, heard, circle,
    /// </summary>
    public Sprite[] imagesFigure;
    public Sprite[] _imagesCell;
    public AnimationClip[] clips;
}
